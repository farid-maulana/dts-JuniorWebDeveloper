<?php
    $connect = mysqli_connect("localhost", "root", "", "penjualanbarang");
?>